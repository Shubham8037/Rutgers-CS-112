package solitaire;

public class CardNode {
	int cardValue;
	CardNode next;
}
